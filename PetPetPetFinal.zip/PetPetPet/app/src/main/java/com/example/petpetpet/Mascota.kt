package com.example.petpetpet

import java.util.*

class Mascota(
    val id: Int,
    val nombre: String,
    val imagen: String,
    val raza: String,
    val sexo: String,
    val fechaNacimiento: Date,
    val dni: String
)